#include<stdio.h>
void main(){
    int n;
    printf("enter the number of elements in array");
    scanf("%d",&n);
    int temp;
    int a[n],b[n];
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n-1-i;j++){
            if(a[j]>=a[j+1]){
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp ;
            }
        }
    }
    for(int i=0;i<n;i++){
        printf("%d",a[i]);
    }
}
